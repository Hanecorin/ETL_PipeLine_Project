# ETL(Pipeline)_miniproject 입니다.
